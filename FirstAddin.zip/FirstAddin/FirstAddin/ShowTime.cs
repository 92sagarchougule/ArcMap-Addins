﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace FirstAddin
{
    public class ShowTime : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public ShowTime()
        {
        }

        protected override void OnClick()
        {
            //
            //  TODO: Sample code showing how to access button host
            //
            
            MessageBox.Show(" Time is : " , ArcMap.Application.Caption = DateTime.Now.ToLongTimeString());
           
        }
        protected override void OnUpdate()
        {
            Enabled = ArcMap.Application != null;
        }
    }

}
