import arcpy
import pythonaddins

class Sample_Data(object):
    """Implementation for Hydrabad_Data_addin.button (Button)"""
    def __init__(self):
        self.enabled = True
        self.checked = False
    def onClick(self):
        arcpy.env.workspace = r'D:\DataforArcObject\Delhi.gdb\Dataset'
        mxd = arcpy.mapping.MapDocument('Current')
        df = arcpy.mapping.ListDataFrames(mxd)[0]
        fclist = arcpy.ListFeatureClasses()
        for fc in fclist:
            lyr = arcpy.mapping.Layer(fc)
            arcpy.mapping.AddLayer(df,lyr)
            arcpy.RefreshActiveView()
            arcpy.RefreshTOC()
