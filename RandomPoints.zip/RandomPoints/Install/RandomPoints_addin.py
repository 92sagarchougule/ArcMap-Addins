import arcpy
import pythonaddins

class ToolClass2(object):
    """Implementation for RandomPoints_addin.tool (Tool)"""
    def __init__(self):
        self.enabled = True
        self.shape = "Rectangle" # Can set to "Line", "Circle" or "Rectangle" for interactive shape drawing and to activate the onLine/Polygon/Circle event sinks.
    def onRectangle(self, rectangle_geometry):
        if(arcpy.Exists(r'in_memory\ran_points')):
            arcpy.Delete_management(r'in_memory\ran_points')
        pfile = arcpy.CreateRandomPoints_management('in_memory','ran_points','',rectangle_geometry,30)
        arcpy.env.addOutputsToMap = True
        pythonaddins.MessageBox("Created 30 Random Points","Message",0)
        
        pout = arcpy.AddXY_management(pfile)
        
        arcpy.AddField_management(pout,"Area","DOUBLE")
        arcpy.RefreshActiveView()
        arcpy.RefreshTOC()

        

        
        
