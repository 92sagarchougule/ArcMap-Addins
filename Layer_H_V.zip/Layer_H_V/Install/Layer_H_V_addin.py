import arcpy
import pythonaddins

class ButtonClass2(object):
    """Implementation for Layer_H_V_addin.button_1 (Button)"""
    def __init__(self):
        self.enabled = False
        self.checked = False
    def onClick(self):
        mxd = arcpy.mapping.MapDocument('Current')
        lylist = arcpy.mapping.ListLayers(mxd)
        for lyr in lylist:
            lyr.visible = False
        arcpy.RefreshActiveView()
        arcpy.RefreshTOC()


class ButtonClass3(object):
    """Implementation for Layer_H_V_addin.button_2 (Button)"""
    def __init__(self):
        self.enabled = False
        self.checked = False
    def onClick(self):
        mxd = arcpy.mapping.MapDocument('Current')
        lylist = arcpy.mapping.ListLayers(mxd)
        for lyr in lylist:
            lyr.visible = True
        arcpy.RefreshActiveView()
        arcpy.RefreshTOC()

class ButtonClass1(object):
    """Implementation for Layer_H_V_addin.button (Button)"""
    def __init__(self):
        self.enabled = True
        self.checked = False
    def onClick(self):
        ind = pythonaddins.MessageBox("Visible Commands","Tools",1)
        if(ind == 'OK'):
            button_1.enabled = True
            button_2.enabled = True
        
