﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.ArcMapUI;

namespace ReMallLayers
{
    public class RemoveAllLayers : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public RemoveAllLayers()
        {
        }

        protected override void OnClick()
        {

            IMxDocument mxdc = ArcMap.Application.Document as IMxDocument;

            IMap map = mxdc.FocusMap;

            map.ClearLayers();

            IActiveView activeView = map as IActiveView;

            activeView.Refresh();

            mxdc.UpdateContents();
            
        }
        protected override void OnUpdate()
        {
            Enabled = ArcMap.Application != null;
        }
    }

}
