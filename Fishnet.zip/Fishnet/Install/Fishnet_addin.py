import arcpy
import pythonaddins

class ClasssNo(object):
    """Implementation for Fishnet_addin.tool (Tool)"""
    def __init__(self):
        self.enabled = True
        self.shape = "Rectangle" # Can set to "Line", "Circle" or "Rectangle" for interactive shape drawing and to activate the onLine/Polygon/Circle event sinks.
    
    def onRectangle(self, rectangle_geometry):
        extent = rectangle_geometry
    # Create a fishnet with 10 rows and 10 columns.
        if arcpy.Exists(r'in_memory\fishnet'):
            arcpy.Delete_management(r'in_memory\fishnet')
        fishnet = arcpy.CreateFishnet_management(r'in_memory\fishnet',
                                '%f %f' %(extent.XMin, extent.YMin),
                                '%f %f' %(extent.XMin, extent.YMax),
                                0, 0, 10, 10,
                                '%f %f' %(extent.XMax, extent.YMax),'NO_LABELS',
                                '%f %f %f %f' %(extent.XMin, extent.YMin, extent.XMax, extent.YMax), 'POLYGON')
        arcpy.RefreshActiveView()
        return fishnet

