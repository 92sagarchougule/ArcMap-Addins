import arcpy
import pythonaddins

class ToolClass2(object):
    """Implementation for GeometryCalculation_addin.tool (Tool)"""
    def __init__(self):
        self.enabled = True
        self.shape = "Circle" # Can set to "Line", "Circle" or "Rectangle" for interactive shape drawing and to activate the onLine/Polygon/Circle event sinks.
    
    def onCircle(self, Circle_geometry):
        print("The Area of selected extent is",Circle_geometry.area)

class ToolClass4(object):
    """Implementation for GeometryCalculation_addin.tool_1 (Tool)"""
    def __init__(self):
        self.enabled = True
        self.shape = "Line" # Can set to "Line", "Circle" or "Rectangle" for interactive shape drawing and to activate the onLine/Polygon/Circle event sinks.
    def onMouseDown(self, x, y, button, shift):
        print("onMouseDown :",x,y)

    def onLine(self, line_geometry):
        print("Length of Line is : ",line_geometry.length)
        
        pass
